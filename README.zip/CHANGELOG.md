# Registro de Alterações

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

---

## 1.0.2 (2024-09-27)

### Funcionalidade

* Ajuste "fator de vencimento" à partir de 22/02/2025

### Adiciona Arquivos

* CHANGELOG.md
* LICENSE

---

## 1.0.1 (2024-04-18)

### Construção do pacote

* Validador de Boleto
* Conversor de Linha Digitável em Código de Barras
* Conversor de Código de Barras em Linha Digitável
* Gerador de código-de-barras
